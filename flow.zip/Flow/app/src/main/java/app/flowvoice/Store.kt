package app.flowvoice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("flow", Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun getInt(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }

    fun history(c: Context): List<Pair<Long, String>> {
        val out = ArrayList<Pair<Long, String>>()
        try {
            val arr = JSONArray(get(c, "history", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Pair(o.getLong("t"), o.getString("x")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(c: Context, list: List<Pair<Long, String>>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("t", p.first)
            o.put("x", p.second)
            arr.put(o)
        }
        put(c, "history", arr.toString())
    }

    @Synchronized
    fun addHistory(c: Context, text: String) {
        val l = ArrayList<Pair<Long, String>>(history(c))
        l.add(0, Pair(System.currentTimeMillis(), text))
        while (l.size > 300) l.removeAt(l.size - 1)
        save(c, l)
    }

    @Synchronized
    fun deleteHistory(c: Context, index: Int) {
        val l = ArrayList<Pair<Long, String>>(history(c))
        if (index in 0 until l.size) l.removeAt(index)
        save(c, l)
    }

    @Synchronized
    fun clearHistory(c: Context) {
        put(c, "history", "[]")
    }
}
