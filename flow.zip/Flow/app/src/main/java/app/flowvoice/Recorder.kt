package app.flowvoice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream

class Recorder(private val onLevel: (Float) -> Unit) {
    private var rec: AudioRecord? = null
    private var th: Thread? = null
    private val buf = ByteArrayOutputStream()

    @Volatile
    private var running = false

    @Volatile
    var peak = 0f

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        val sr = 16000
        val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val r: AudioRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, min * 2
            )
        } catch (e: Exception) {
            return false
        }
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release()
            return false
        }
        try {
            r.startRecording()
        } catch (e: Exception) {
            r.release()
            return false
        }
        if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
            r.release()
            return false
        }
        rec = r
        peak = 0f
        synchronized(buf) { buf.reset() }
        running = true
        th = Thread {
            val b = ByteArray(2048)
            while (running) {
                val n = r.read(b, 0, b.size)
                if (n <= 0) {
                    if (n < 0) break
                    continue
                }
                synchronized(buf) { buf.write(b, 0, n) }
                var sum = 0.0
                var i = 0
                var cnt = 0
                while (i + 1 < n) {
                    val s = ((b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)).toShort().toInt()
                    sum += s.toDouble() * s
                    val a = Math.abs(s) / 32768f
                    if (a > peak) peak = a
                    cnt++
                    i += 2
                }
                if (cnt > 0) onLevel((Math.sqrt(sum / cnt) / 32768.0).toFloat())
            }
        }
        th?.start()
        return true
    }

    fun stop(): ByteArray {
        running = false
        try {
            th?.join(400)
        } catch (_: Exception) {
        }
        try {
            rec?.stop()
        } catch (_: Exception) {
        }
        try {
            rec?.release()
        } catch (_: Exception) {
        }
        rec = null
        return synchronized(buf) { buf.toByteArray() }
    }
}
