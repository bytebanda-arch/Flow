package app.flowvoice

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast

class FlowService : AccessibilityService() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: BubbleView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var lastTop = -1
    private var frac = 0f
    private var anim: ValueAnimator? = null
    private var recording = false
    private var busy = false
    private var sessionId = 0
    private val rec = Recorder { lv -> main.post { bubble?.push(lv) } }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!::wm.isInitialized) return
        refresh()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideBubble()
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- bubble window
    private fun scale(): Float = Store.getInt(this, "bubbleSize", 100) / 100f
    private fun circlePx(): Int = (44 * resources.displayMetrics.density * scale()).toInt()
    private fun pillPx(): Int = (190 * resources.displayMetrics.density * scale()).toInt()

    private fun refresh() {
        var top = -1
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                    val r = Rect()
                    w.getBoundsInScreen(r)
                    if (r.height() > 0) top = r.top
                }
            }
        } catch (_: Exception) {
        }
        if (top >= 0) {
            lastTop = top
            showBubble()
        } else if (!recording && !busy) {
            hideBubble()
        }
    }

    private fun showBubble() {
        if (bubble == null) {
            val v = BubbleView(this)
            v.scale = scale()
            v.onDown = { onDown() }
            v.onUp = { onUp() }
            val l = WindowManager.LayoutParams(
                circlePx(), circlePx(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            l.gravity = Gravity.TOP or Gravity.START
            frac = 0f
            v.frac = 0f
            lp = l
            bubble = v
            try {
                wm.addView(v, l)
            } catch (e: Exception) {
                Log.w("Flow", "addView failed", e)
                bubble = null
                lp = null
                return
            }
        } else {
            bubble?.scale = scale()
        }
        relayout()
    }

    private fun hideBubble() {
        anim?.cancel()
        val v = bubble ?: return
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
        bubble = null
        lp = null
        frac = 0f
    }

    private fun relayout() {
        val v = bubble ?: return
        val l = lp ?: return
        val c = circlePx()
        val pw = pillPx()
        val w = (c + (pw - c) * frac).toInt()
        val dm = resources.displayMetrics
        val margin = (12 * dm.density).toInt()
        val lift = (Store.getInt(this, "bubbleLift", 12) * dm.density).toInt()
        l.width = w
        l.height = c
        l.x = if (Store.get(this, "bubbleSide", "right") == "right") dm.widthPixels - margin - w else margin
        l.y = lastTop - c - lift
        try {
            wm.updateViewLayout(v, l)
        } catch (_: Exception) {
        }
    }

    private fun animateTo(target: Float) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(frac, target)
        a.duration = 180
        a.addUpdateListener {
            frac = it.animatedValue as Float
            bubble?.frac = frac
            relayout()
        }
        a.start()
        anim = a
    }

    private fun setState(s: String) {
        val v = bubble ?: return
        v.state = s
        v.stateT = System.currentTimeMillis()
        v.invalidate()
    }

    // ---------------------------------------------------------------- touch -> recording
    private fun holdMode() = Store.get(this, "bubbleMode", "hold") == "hold"

    private fun onDown() {
        bubble?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        if (busy) return
        if (holdMode()) startRec()
    }

    private fun onUp() {
        if (holdMode()) {
            if (recording) stopRec()
        } else {
            if (busy) return
            if (recording) stopRec() else startRec()
        }
    }

    private fun startRec() {
        if (recording || busy) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Open Flow and allow the microphone")
            return
        }
        if (!rec.start()) {
            toast("Could not start the microphone")
            flash("error")
            return
        }
        sessionId++
        recording = true
        bubble?.clearHist()
        setState("listening")
        animateTo(1f)
    }

    private fun stopRec() {
        recording = false
        val pcm = rec.stop()
        val peak = rec.peak
        setState("processing")
        busy = true
        sessionId++
        Thread {
            var result: String? = null
            var err: String? = null
            try {
                if (pcm.size >= 12800 && peak > 0.01f) {
                    result = Api.process(applicationContext, Api.wav(pcm))
                }
            } catch (e: Exception) {
                err = e.message ?: "Something went wrong"
                Log.w("Flow", "process failed", e)
            }
            main.post { finishJob(result, err) }
        }.start()
    }

    private fun finishJob(text: String?, err: String?) {
        busy = false
        if (err != null) {
            toast(err)
            flash("error")
            return
        }
        if (text.isNullOrBlank()) {
            setState("idle")
            animateTo(0f)
            refresh()
            return
        }
        val ok = insertText(text)
        Store.addHistory(applicationContext, text)
        if (!ok) toast("Copied. Paste it into the text box")
        flash("done")
    }

    private fun flash(s: String) {
        setState(s)
        val id = sessionId
        main.postDelayed({
            if (id == sessionId && !recording && !busy) {
                setState("idle")
                animateTo(0f)
                refresh()
            }
        }, if (s == "error") 1500L else 900L)
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- typing into the focused box
    private fun focusedInput(): AccessibilityNodeInfo? {
        try {
            val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (n != null && n.isEditable) return n
        } catch (_: Exception) {
        }
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                    val n = w.root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    if (n != null && n.isEditable) return n
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun insertText(text: String): Boolean {
        val node = focusedInput()
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val old: ClipData? = try {
            cm.primaryClip
        } catch (_: Exception) {
            null
        }
        val full = text + " "
        cm.setPrimaryClip(ClipData.newPlainText("flow", full))
        if (node == null || node.isPassword) return false

        var ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        if (!ok) {
            val cur = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
            val s0 = node.textSelectionStart
            val e0 = node.textSelectionEnd
            val s = if (s0 < 0) cur.length else Math.min(s0, cur.length)
            val e = if (e0 < 0) cur.length else Math.min(e0, cur.length)
            val a = Math.min(s, e)
            val b = Math.max(s, e)
            val args = Bundle()
            args.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                cur.substring(0, a) + full + cur.substring(b)
            )
            ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (ok) {
                val pos = a + full.length
                val sel = Bundle()
                sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
                sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
                node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            }
        }
        if (ok && old != null) {
            main.postDelayed({
                try {
                    cm.setPrimaryClip(old)
                } catch (_: Exception) {
                }
            }, 900)
        }
        return ok
    }
}
