package app.flowvoice

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Api {
    private const val GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
    private const val GEMINI_MODEL = "gemini-flash-lite-latest"
    private const val PROMPT =
        "Hello, how are you? नमस्ते, आप कैसे हैं? Mujhe kal office jaana hai, meeting ke baad call karunga."

    private val URDU_LIKE = setOf("urdu", "ur", "arabic", "ar", "persian", "fa", "farsi", "pashto", "sindhi")
    private val DEV = Regex("[\\u0900-\\u097F]")
    private val BEN = Regex("[\\u0980-\\u09FF]")
    private val ARAB = Regex("[\\u0600-\\u06FF]")
    private val CUES = Regex(
        "\\b(no|nope|nahi|nahin|sorry|actually|wait|oops|scratch that|i mean|matlab)\\b",
        RegexOption.IGNORE_CASE
    )
    private val HI_CUES = listOf("नहीं", "नही", "मतलब", "रुको", "सॉरी", "ओह", "वेट")
    private val FILLERS = Regex(
        "\\b(um+|uh+|hmm+|er+)\\b[,.]?\\s*|(उम्म+|हम्म+)[,.]?\\s*",
        RegexOption.IGNORE_CASE
    )

    fun wav(pcm: ByteArray, sr: Int = 16000): ByteArray {
        val n = pcm.size
        val h = ByteArray(44)
        fun w32(o: Int, v: Int) {
            h[o] = v.toByte(); h[o + 1] = (v shr 8).toByte()
            h[o + 2] = (v shr 16).toByte(); h[o + 3] = (v shr 24).toByte()
        }
        fun w16(o: Int, v: Int) {
            h[o] = v.toByte(); h[o + 1] = (v shr 8).toByte()
        }
        "RIFF".toByteArray().copyInto(h, 0)
        w32(4, 36 + n)
        "WAVEfmt ".toByteArray().copyInto(h, 8)
        w32(16, 16); w16(20, 1); w16(22, 1); w32(24, sr); w32(28, sr * 2); w16(32, 2); w16(34, 16)
        "data".toByteArray().copyInto(h, 36)
        w32(40, n)
        return h + pcm
    }

    private fun multipart(fields: Map<String, String>, file: ByteArray, boundary: String): ByteArray {
        val o = ByteArrayOutputStream()
        for ((k, v) in fields) {
            o.write(
                ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + k + "\"\r\n\r\n" + v + "\r\n")
                    .toByteArray(Charsets.UTF_8)
            )
        }
        o.write(
            ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n" +
                "Content-Type: audio/wav\r\n\r\n").toByteArray()
        )
        o.write(file)
        o.write(("\r\n--" + boundary + "--\r\n").toByteArray())
        return o.toByteArray()
    }

    private fun readAll(conn: HttpURLConnection, name: String): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException(name + " HTTP " + code + ": " + txt.take(160))
        return txt
    }

    private fun groqCall(ctx: Context, wav: ByteArray, language: String?): JSONObject {
        val key = Store.get(ctx, "groqKey", "").trim().trim('"')
        if (key.isEmpty()) throw RuntimeException("Add your Groq key in Settings")
        val model = if (Store.get(ctx, "groqModel", "turbo") == "v3") "whisper-large-v3" else "whisper-large-v3-turbo"
        val fields = LinkedHashMap<String, String>()
        fields["model"] = model
        fields["response_format"] = "verbose_json"
        fields["temperature"] = "0"
        fields["prompt"] = PROMPT
        if (language != null) fields["language"] = language
        val boundary = "----flow" + System.currentTimeMillis()
        val body = multipart(fields, wav, boundary)
        val conn = URL(GROQ_URL).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 10000
        conn.readTimeout = 25000
        conn.setRequestProperty("Authorization", "Bearer " + key)
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary)
        conn.setRequestProperty("User-Agent", "flow-android/1.0")
        conn.outputStream.use { it.write(body) }
        return JSONObject(readAll(conn, "Groq"))
    }

    private fun transcribe(ctx: Context, wav: ByteArray): String {
        val pick = Store.get(ctx, "speakLang", "auto")
        val lang: String? = if (pick == "auto") null else pick
        var j = groqCall(ctx, wav, lang)
        if (lang == null && URDU_LIKE.contains(j.optString("language", "").lowercase())) {
            j = groqCall(ctx, wav, "hi")
        }
        return j.optString("text", "").trim()
    }

    private fun cleanPrompt(ctx: Context): String {
        val hi = Store.get(ctx, "hindiOut", "roman")
        val bn = Store.get(ctx, "bengaliOut", "roman")
        val en = Store.get(ctx, "englishFix", "on")
        val sb = StringBuilder()
        sb.append("You are a dictation post-processor. The input is a speech-to-text transcript. Apply these rules. ")
        if (hi == "roman") {
            sb.append("1) HINDI (Devanagari or Urdu script): rewrite it in natural Roman-letter Hinglish, the way Indians type on WhatsApp (for example: 'mujhe kal office jaana hai'). Keep English words in normal English spelling. ")
        } else {
            sb.append("1) HINDI: write it in Devanagari script; if it arrives in Urdu/Arabic script, convert it to Devanagari. Keep English words in English letters. ")
        }
        if (bn == "roman") {
            sb.append("2) BENGALI (Bengali script): rewrite it in Roman-letter Banglish, the way Bengalis type on WhatsApp (for example: 'aami kal office jabo'). ")
        } else {
            sb.append("2) BENGALI: keep it in Bengali script. ")
        }
        if (en == "on") {
            sb.append("3) ENGLISH: lightly fix grammar, spelling and wrong word usage, keeping the meaning and tone. ")
        } else {
            sb.append("3) ENGLISH: keep it exactly as spoken. ")
        }
        sb.append("4) MIXED speech: apply the rules to each part. ")
        sb.append("5) If the speaker corrects themselves (e.g. 'come at 220, no 230', 'nahi nahi', 'I mean', 'matlab'), keep ONLY the final corrected version. ")
        sb.append("6) Remove filler words (um, uh, hmm) and add punctuation and capitalization. ")
        sb.append("7) Never translate from one language to another. Do not add, explain or answer anything. Output ONLY the final text.")
        return sb.toString()
    }

    private fun needsAi(ctx: Context, t: String): Boolean {
        if (ARAB.containsMatchIn(t)) return true
        val hasDev = DEV.containsMatchIn(t)
        val hasBen = BEN.containsMatchIn(t)
        if (hasDev && Store.get(ctx, "hindiOut", "roman") == "roman") return true
        if (hasBen && Store.get(ctx, "bengaliOut", "roman") == "roman") return true
        if (CUES.containsMatchIn(t) || HI_CUES.any { t.contains(it) }) return true
        if (!hasDev && !hasBen && Store.get(ctx, "englishFix", "on") == "on") return true
        return false
    }

    private fun gemini(ctx: Context, text: String): String? {
        val key = Store.get(ctx, "geminiKey", "").trim().trim('"')
        if (key.isEmpty()) return null
        val parts = JSONArray().put(JSONObject().put("text", cleanPrompt(ctx) + "\n\nTEXT:\n" + text))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .toString().toByteArray(Charsets.UTF_8)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" + GEMINI_MODEL + ":generateContent"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 8000
        conn.readTimeout = 12000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body) }
        val j = JSONObject(readAll(conn, "Gemini"))
        return j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getString("text").trim()
    }

    /** Full pipeline: speech -> text -> cleanup. Returns null when nothing was heard. */
    fun process(ctx: Context, wav: ByteArray): String? {
        var text = transcribe(ctx, wav)
        text = FILLERS.replace(text, "").replace(Regex("\\s+"), " ").trim()
        if (text.isEmpty()) return null
        text = text.substring(0, 1).uppercase() + text.substring(1)
        if (needsAi(ctx, text)) {
            try {
                val r = gemini(ctx, text)
                if (!r.isNullOrEmpty()) text = r
            } catch (e: Exception) {
                Log.w("Flow", "Gemini cleanup failed", e)
            }
        }
        return text
    }
}
