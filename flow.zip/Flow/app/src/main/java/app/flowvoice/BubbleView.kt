package app.flowvoice

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** The floating bubble. It is drawn to fill its whole window; the service resizes the window. */
class BubbleView(ctx: Context) : View(ctx) {
    var state = "idle"          // idle, listening, processing, done, error
    var stateT = System.currentTimeMillis()
    var frac = 0f               // 0 = small circle, 1 = full pill
    var scale = 1f
    var onDown: (() -> Unit)? = null
    var onUp: (() -> Unit)? = null

    private val hist = FloatArray(22)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private val rect = RectF()

    fun push(level: Float) {
        System.arraycopy(hist, 1, hist, 0, hist.size - 1)
        val v = Math.pow(level * 14.0, 0.7).toFloat() * (0.8f + 0.2f * Math.random().toFloat())
        hist[hist.size - 1] = Math.min(1f, v)
    }

    fun clearHist() {
        java.util.Arrays.fill(hist, 0f)
    }

    private fun a(alpha: Float): Int = (255f * Math.max(0f, Math.min(1f, alpha))).toInt()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val u = d * scale
        val r = h / 2f
        val e = frac * frac * (3f - 2f * frac)
        val now = System.currentTimeMillis()
        val t = (now - stateT) / 1000f
        val tick = now / 1000f

        // body
        val g = (92 + (14 - 92) * e).toInt()
        p.style = Paint.Style.FILL
        p.color = Color.rgb(g, g, g + 2)
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = Math.max(1f, d)
        p.color = Color.argb((60 - 24 * e).toInt(), 255, 255, 255)
        rect.set(0.5f, 0.5f, w - 0.5f, h - 0.5f)
        c.drawRoundRect(rect, r, r, p)

        val cx = w / 2f
        val cy = h / 2f
        p.style = Paint.Style.FILL

        // idle glyph: three short bars
        val ia = 1f - Math.min(1f, e * 2.2f)
        if (ia > 0f) {
            p.color = Color.argb(a(0.8f * ia), 255, 255, 255)
            val hs = floatArrayOf(5f, 9f, 5f)
            for (i in 0..2) {
                val bx = cx + (i - 1) * 6f * u
                rect.set(bx - 1.5f * u, cy - hs[i] * u * 0.5f * 1.4f, bx + 1.5f * u, cy + hs[i] * u * 0.5f * 1.4f)
                c.drawRoundRect(rect, 1.5f * u, 1.5f * u, p)
            }
        }

        val ca = Math.max(0f, Math.min(1f, (e - 0.5f) / 0.5f))
        if (ca <= 0f) {
            if (state != "idle") postInvalidateOnAnimation()
            return
        }

        when (state) {
            "listening" -> {
                val n = hist.size
                val gap = 7f * u
                val bw = 2.8f * u
                val bx0 = cx - gap * (n - 1) / 2f
                val maxh = h * 0.62f
                for (i in 0 until n) {
                    val tp = Math.min(1f, Math.min((i + 1) / 6f, (n - i) / 6f))
                    val bh = bw + hist[i] * maxh * (0.3f + 0.7f * tp)
                    p.color = Color.argb(a(ca * (0.47f + 0.5f * tp)), 255, 255, 255)
                    rect.set(bx0 + i * gap - bw / 2f, cy - bh / 2f, bx0 + i * gap + bw / 2f, cy + bh / 2f)
                    c.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                }
            }
            "processing" -> {
                val n = 9
                val gap = 7.5f * u
                val bx0 = cx - 22f * u - gap * (n - 1) / 2f
                for (i in 0 until n) {
                    val s = 0.5f + 0.5f * Math.sin((tick * 6f - i * 0.7f).toDouble()).toFloat()
                    p.color = Color.argb(a(ca * (0.3f + 0.7f * s)), 255, 255, 255)
                    c.drawCircle(bx0 + i * gap, cy, 1.8f * u, p)
                }
                val sx = cx + 58f * u
                val rr = 8f * u
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.2f * u
                p.strokeCap = Paint.Cap.ROUND
                p.color = Color.argb(a(ca * 0.16f), 255, 255, 255)
                c.drawCircle(sx, cy, rr, p)
                p.color = Color.argb(a(ca * 0.92f), 255, 255, 255)
                rect.set(sx - rr, cy - rr, sx + rr, cy + rr)
                c.drawArc(rect, -((tick * 520f) % 360f), 100f, false, p)
                p.strokeCap = Paint.Cap.BUTT
            }
            "done" -> {
                val prog = Math.min(1f, t / 0.25f)
                val ax = cx - 9f * u; val ay = cy + 0.5f * u
                val bx = cx - 2.5f * u; val by = cy + 7f * u
                val dx = cx + 10f * u; val dy = cy - 7f * u
                val l1 = Math.hypot((bx - ax).toDouble(), (by - ay).toDouble()).toFloat()
                val l2 = Math.hypot((dx - bx).toDouble(), (dy - by).toDouble()).toFloat()
                val dist = prog * (l1 + l2)
                val path = Path()
                path.moveTo(ax, ay)
                if (dist <= l1) {
                    val f = dist / l1
                    path.lineTo(ax + (bx - ax) * f, ay + (by - ay) * f)
                } else {
                    path.lineTo(bx, by)
                    val f = (dist - l1) / l2
                    path.lineTo(bx + (dx - bx) * f, by + (dy - by) * f)
                }
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                p.strokeWidth = 7f * u
                p.color = Color.argb(a(ca * 0.2f), 74, 222, 128)
                c.drawPath(path, p)
                p.strokeWidth = 3.4f * u
                p.color = Color.argb(a(ca), 74, 222, 128)
                c.drawPath(path, p)
                p.strokeCap = Paint.Cap.BUTT
            }
            "error" -> {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = 3.4f * u
                p.color = Color.argb(a(ca), 248, 113, 113)
                c.drawLine(cx - 7f * u, cy - 7f * u, cx + 7f * u, cy + 7f * u, p)
                c.drawLine(cx + 7f * u, cy - 7f * u, cx - 7f * u, cy + 7f * u, p)
                p.strokeCap = Paint.Cap.BUTT
            }
        }
        if (state == "listening" || state == "processing" || state == "done") postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> onDown?.invoke()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onUp?.invoke()
        }
        return true
    }
}
