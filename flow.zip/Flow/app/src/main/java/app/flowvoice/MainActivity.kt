package app.flowvoice

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var navHome: TextView
    private lateinit var navSettings: TextView
    private var tab = 0

    private val bg = Color.parseColor("#0E0F12")
    private val card = Color.parseColor("#181A1F")
    private val line = Color.parseColor("#2A2D34")
    private val dim = Color.parseColor("#9AA0AB")
    private val accent = Color.parseColor("#8AB4FF")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg
        window.navigationBarColor = card
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this)
        nav.setBackgroundColor(card)
        navHome = navItem("Home") { tab = 0; render() }
        navSettings = navItem("Settings") { tab = 1; render() }
        nav.addView(navHome, LinearLayout.LayoutParams(0, dp(54), 1f))
        nav.addView(navSettings, LinearLayout.LayoutParams(0, dp(54), 1f))
        root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try {
                startForegroundService(Intent(this, KeepAliveService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        onResume()
    }

    // ------------------------------------------------------------------ small view helpers
    private fun navItem(label: String, click: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setOnClickListener { click() }
        return t
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun column(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(18), dp(20), dp(18), dp(28))
        return c
    }

    private fun box(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val g = GradientDrawable()
        g.setColor(card)
        g.cornerRadius = dp(14).toFloat()
        g.setStroke(dp(1), line)
        c.background = g
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun gap(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(-1, dp(h))
        return v
    }

    private fun smallButton(label: String, click: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(bg)
        val g = GradientDrawable()
        g.setColor(accent)
        g.cornerRadius = dp(18).toFloat()
        b.background = g
        b.setPadding(dp(16), 0, dp(16), 0)
        b.minHeight = 0
        b.minimumHeight = dp(36)
        b.setOnClickListener { click() }
        return b
    }

    private fun statusRow(label: String, ok: Boolean?, btn: String, click: () -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(8), 0, dp(8))
        val mark = if (ok == true) "\u2713  " else if (ok == false) "\u25CB  " else ""
        val t = tv(mark + label, 14f, if (ok == true) Color.parseColor("#6EE7A0") else Color.WHITE)
        r.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        if (ok != true) r.addView(smallButton(btn, click))
        return r
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName + "/" + FlowService::class.java.name) ||
            s.contains(packageName + "/.FlowService")
    }

    private fun openAppInfo() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
        )
    }

    // ------------------------------------------------------------------ screens
    private fun render() {
        navHome.setTextColor(if (tab == 0) accent else dim)
        navSettings.setTextColor(if (tab == 1) accent else dim)
        content.removeAllViews()
        val sv = ScrollView(this)
        sv.addView(if (tab == 0) home() else settings())
        content.addView(sv, FrameLayout.LayoutParams(-1, -1))
    }

    private fun home(): View {
        val col = column()
        col.addView(tv("Flow", 30f, Color.WHITE, true))
        col.addView(tv("Hold the bubble above any keyboard, speak, and let go.", 14f, dim))

        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notifOk = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val a11 = a11yOn()
        val keysOk = Store.get(this, "groqKey", "").isNotBlank()

        val setup = box()
        setup.addView(tv(if (micOk && a11 && keysOk) "Ready to use" else "Finish setup", 16f, Color.WHITE, true))
        setup.addView(statusRow("Microphone", micOk, "Allow") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        if (Build.VERSION.SDK_INT >= 33) {
            setup.addView(statusRow("Notifications", notifOk, "Allow") {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
            })
        }
        setup.addView(statusRow("Accessibility: shows the bubble and types for you", a11, "Open") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        setup.addView(statusRow("Groq key", keysOk, "Add") { tab = 1; render() })
        setup.addView(statusRow("Battery: set to Unrestricted", null, "App info") { openAppInfo() })
        if (!a11 && Build.VERSION.SDK_INT >= 33) {
            setup.addView(
                tv(
                    "If Accessibility is greyed out: App info, tap the three dots at the top right, then Allow restricted settings.",
                    12f, dim
                )
            )
        }
        col.addView(setup)

        val h = Store.history(this)
        col.addView(gap(22))
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("History", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (h.isNotEmpty()) {
            head.addView(smallButton("Clear all") {
                Store.clearHistory(this)
                render()
            })
        }
        col.addView(head)
        if (h.isEmpty()) {
            col.addView(gap(8))
            col.addView(tv("Nothing yet. Say something in any app and it shows up here.", 14f, dim))
        }
        val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault())
        for ((i, p) in h.withIndex()) {
            val c = box()
            c.addView(tv(fmt.format(Date(p.first)), 12f, dim))
            c.addView(tv(p.second, 16f, Color.WHITE))
            c.setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("flow", p.second))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
            c.setOnLongClickListener {
                Store.deleteHistory(this, i)
                render()
                true
            }
            col.addView(c)
        }
        if (h.isNotEmpty()) col.addView(tv("Tap to copy. Press and hold to delete.", 12f, dim))
        return col
    }

    private fun label(text: String): TextView {
        val t = tv(text, 13f, dim)
        t.setPadding(0, dp(14), 0, dp(4))
        return t
    }

    private fun keyField(title: String, key: String, hint: String, parent: LinearLayout) {
        parent.addView(label(title))
        val et = EditText(this)
        et.setText(Store.get(this, key, ""))
        et.hint = hint
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(Color.parseColor("#5C616B"))
        et.textSize = 14f
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Store.put(this@MainActivity, key, (s?.toString() ?: "").trim())
            }
        })
        parent.addView(et)
    }

    private fun choice(title: String, key: String, def: String, vals: List<String>, names: List<String>, parent: LinearLayout) {
        parent.addView(label(title))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(Math.max(0, vals.indexOf(Store.get(this, key, def))))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Store.put(this@MainActivity, key, vals[pos])
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        parent.addView(sp)
    }

    private fun slider(title: String, key: String, min: Int, max: Int, def: Int, unit: String, parent: LinearLayout) {
        val t = label(title + ": " + Store.getInt(this, key, def) + unit)
        parent.addView(t)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = Store.getInt(this, key, def) - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Store.putInt(this@MainActivity, key, p + min)
                t.text = title + ": " + (p + min) + unit
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb)
    }

    private fun settings(): View {
        val col = column()
        col.addView(tv("Settings", 30f, Color.WHITE, true))

        val keys = box()
        keys.addView(tv("Keys", 16f, Color.WHITE, true))
        keyField("Groq key (speech to text)", "groqKey", "Paste from console.groq.com/keys", keys)
        keyField("Gemini key (cleanup and Hinglish)", "geminiKey", "Paste from aistudio.google.com/apikey", keys)
        col.addView(keys)

        val lang = box()
        lang.addView(tv("Languages", 16f, Color.WHITE, true))
        choice(
            "Language I speak", "speakLang", "auto",
            listOf("auto", "hi", "bn", "en"), listOf("Auto detect", "Hindi", "Bengali", "English"), lang
        )
        choice(
            "When I speak Hindi, write", "hindiOut", "roman",
            listOf("roman", "native"), listOf("Hinglish (Roman letters)", "Hindi (Devanagari)"), lang
        )
        choice(
            "When I speak Bengali, write", "bengaliOut", "roman",
            listOf("roman", "native"), listOf("Banglish (Roman letters)", "Bengali script"), lang
        )
        choice(
            "When I speak English", "englishFix", "on",
            listOf("on", "off"), listOf("Fix my mistakes", "Keep exactly as spoken"), lang
        )
        col.addView(lang)

        val speech = box()
        speech.addView(tv("Speech", 16f, Color.WHITE, true))
        choice(
            "Speech model", "groqModel", "turbo",
            listOf("turbo", "v3"), listOf("Fast (large-v3-turbo)", "Most accurate (large-v3)"), speech
        )
        col.addView(speech)

        val bub = box()
        bub.addView(tv("Bubble", 16f, Color.WHITE, true))
        choice(
            "How I use it", "bubbleMode", "hold",
            listOf("hold", "tap"), listOf("Hold to talk", "Tap to start, tap to stop"), bub
        )
        choice(
            "Side of the screen", "bubbleSide", "right",
            listOf("right", "left"), listOf("Right", "Left"), bub
        )
        slider("Size", "bubbleSize", 60, 180, 100, "%", bub)
        slider("Height above keyboard", "bubbleLift", 0, 200, 12, " dp", bub)
        col.addView(bub)

        col.addView(gap(14))
        col.addView(tv("Changes save as you make them and apply the next time the bubble appears.", 12f, dim))
        return col
    }
}
