Flow for Android (Hinglish / Banglish voice typing bubble)

Keys are NOT in this code. Open the app > Settings and paste:
  - Groq key   (console.groq.com/keys)
  - Gemini key (aistudio.google.com/apikey)

Build: GitHub Actions turns this folder into app-debug.apk (see the steps in the chat).
